// ==UserScript==
// @name         Ẩn Reels, Lối tắt, Story, "Bạn đang nghĩ gì?" trên Facebook
// @namespace    https://facebook.com
// @version      1.0
// @description  Ẩn các phần không mong muốn trên Facebook Web
// @author       Bạn
// @match        *://*.facebook.com/*
// @grant        none
// @run-at       document-idle
// ==/UserScript==

(function() {
    'use strict';

    function hideElements() {
        const selectors = [
            'div[aria-label="Reels"]',
            'a[href*="/reels/"]',
            'div[role="complementary"]',
            'div[aria-label="Lối tắt"]',
            'div[aria-label="khay tin"]',
            'div[aria-label="Tạo bài viết"]',
            '.x1hc1fzr.x1unhpq9.x6o7n8i',
            '.x6s0dn4.x78zum5.x5yr21d.xl56j7k.x1xegmmw',
            'div[role="feed"] > div:first-child',
            '.x11t971q.xvc5jky.x1vqzy7e.x13qq4wz.xaooukx',
        ];

        selectors.forEach(selector => {
            document.querySelectorAll(selector).forEach(el => {
                el.style.display = 'none';
            });
        });

         const selectors1 = [
            'style-scope ytd-two-column-browse-results-renderer',

        ];

        selectors1.forEach(selector => {
            document.querySelectorAll(selector).forEach(el => {
                el.style.display = 'flex';
            });
        });
    }

    // Ẩn ngay khi trang tải xong
    hideElements();

    // Quan sát DOM để ẩn lại nếu Facebook tải nội dung động
    const observer = new MutationObserver(hideElements);
    observer.observe(document.body, { childList: true, subtree: true });

})();
